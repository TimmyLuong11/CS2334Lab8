public class Todo {/*
Lab Section_________: 12
Last Modified_______: 2019-03-26
OU ID_______________: 113401608
OU EMAIL____________: timothy.luong@ou.edu

Tasks:
1. Complete BoardGame/BoardGameTest
2. Complete Color/ColorTest
3. Complete Driver
4. Complete GamePiece/GamePieceTest
5. Complete Location/LocationTest
6. Complete Shape/ShapeTest

Estimated Time (minutes):
1. 60
2. 15
3. 30
4. 45
5. 15
6. 30

Actual Time (minutes):
1. 120
2. 30
3. 45
4. 60
5. 30
6. 45
*/}
